module.exports = {
  myfunction: function (event, context) {
    console.log(event);
    return "Hello world!";
  }
}
