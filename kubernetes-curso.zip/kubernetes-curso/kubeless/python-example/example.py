def hello(event, context):
  print event
  return event['data']
