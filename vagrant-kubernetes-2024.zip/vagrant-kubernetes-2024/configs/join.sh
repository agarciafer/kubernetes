kubeadm join 10.0.0.10:6443 --token en0stj.081v12dmn01rdp3e --discovery-token-ca-cert-hash sha256:42345b203d7337734df51f022bffe850a30f891586293dc5093c45030595ac78 
