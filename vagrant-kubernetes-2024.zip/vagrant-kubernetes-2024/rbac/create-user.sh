#!/bin/bash
#Resumen del proceso:
#Genera una clave privada y una CSR para el usuario.
#Firma la CSR utilizando una CA existente.
#Crea un archivo kubeconfig para el usuario con los certificados y credenciales embebidos.
#Configura el cluster, las credenciales y el contexto.
#Activa el contexto para que el usuario pueda interactuar con el cluster usando kubectl.
#Este script es ideal para la creación automatizada de usuarios en un cluster Kubernetes, permitiéndoles #autenticarse mediante certificados y facilitando la configuración de acceso al cluster. 

USERNAME=$1
GROUP=$2
FOLDER="rbac"

openssl genrsa -out ${FOLDER}/${USERNAME}.key 2048

openssl req -new \
-key ${FOLDER}/${USERNAME}.key -out ${FOLDER}/${USERNAME}.csr \
-subj "/CN=${USERNAME}/O=${GROUP}"

openssl x509 -req -days 365 \
  -in ${FOLDER}/${USERNAME}.csr \
  -CA rbac/ca.crt \
  -CAkey rbac/ca.key \
  -CAcreateserial \
  -out ${FOLDER}/${USERNAME}.crt

kubectl --kubeconfig=${FOLDER}/${USERNAME}-config \
  config set-cluster kubernetes \
  --server https://10.0.0.10:6443 \
  --certificate-authority=rbac/ca.crt \
  --embed-certs=true

kubectl --kubeconfig=${FOLDER}/${USERNAME}-config \
  config set-credentials ${USERNAME} \
  --client-certificate=${FOLDER}/${USERNAME}.crt \
  --client-key=${FOLDER}/${USERNAME}.key \
  --embed-certs=true

kubectl --kubeconfig=${FOLDER}/${USERNAME}-config \
  config set-context ${USERNAME}@kubernetes \
  --user=${USERNAME} \
  --cluster=kubernetes \
  --namespace=default

kubectl --kubeconfig=${FOLDER}/${USERNAME}-config \
  config use-context ${USERNAME}@kubernetes

